#pragma once
#include "objBase.h"
#include "map.h"


class WeaponBaseItem : public BaseVector
{
public:
	WeaponBaseItem(int WeaponID,int WeaponNo,Point p,CMap* m);
	int Action(const ObjList&, ObjList&);
	void Draw();
	void CutSprite(int ID,int No);
private:
	int weapon_id = { -1 };//����̎��ID
	int weapon_no = { -1 };//����̔ԍ�ID(����0�ԁA1�ԂȂ�)
	bool isHit = false;
	bool isGet = false;
	bool isPushE = false;
};