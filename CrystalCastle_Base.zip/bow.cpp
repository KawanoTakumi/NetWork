#include "bow.h"
#include "damageObj.h"
#include "function.h"

CBow::CBow(Point p, Vector v,int _No, int _calc_damage, CMap* _m) {

	sprite.img = Resource::bowImg;
	sprite.cutX = 0;
	sprite.cutY = 0;
	sprite.width = 32;
	sprite.height = 32;
	sprite.cutX = _No * sprite.width;
	pos = p;
	vec = Vector_SetLength(v, 4.0f * (_No+1));//��

	sprite.angle = atan2(vec.y, vec.x);
	calc_damage = _calc_damage;//�v�Z��̃_���[�W
	map = _m;
	ID = (int)ObjID::WEAPON;
	pri = 1;
	WeaponID = 1;
}

int CBow::Action(const ObjList& base, ObjList& add_base) 
{
	pos = Add_Point_Vector(pos, vec);

	//�|��̏ꍇ�A�ǂ��ђʂ��Ȃ�
	if (!map->CanMove(pos, 32, 32))
		FLAG = false;

	//��莞�Ԍo�߂��������
	life--;
	if (life == 0)FLAG = false;

	return 0;
}

void CBow::Draw()
{
	//�`��ʒu���v�Z
	Point draw_pos = CameraToScreen(pos, map->camera);

	//�`��
	sprite.Draw(draw_pos.x, draw_pos.y);
}