//��
#pragma once
#include "weapon.h"
#include "map.h"

class CBow :public CWeaponBase
{
public:
	//�ʒu,�ړ��x�N�g��
	CBow(Point, Vector,int,int, CMap*);
	int Action(const ObjList&, ObjList&);
	void Draw();
};