//�����[�X
#include "Resource.h"

int Resource::playerImg;
int Resource::effectImg;
int Resource::enemy5Img;
int Resource::bowImg;
int Resource::magicImg;
int Resource::weaponImg;

int Resource::itemImg;

int Resource::Boss_Img;

int Resource::enemy_projectile_Img;


int Resource::treasure_Img;
int Resource::map_cave_Img;


//�摜�ǂݍ���
void Resource::Load()
{
	playerImg = LoadGraph("image\\player32.png");//�v���C���[
	effectImg = LoadGraph("image\\effect02.png");//�G�t�F�N�g
	enemy5Img = LoadGraph("image\\enemy5.png");//�G���G
	
	weaponImg = LoadGraph("image\\weapon_image.png");//����摜
	magicImg = LoadGraph("image\\Projectile_Magic.png");//���@�̉摜
	bowImg = LoadGraph("image\\Projectile_Bow.png");//��̉摜

	itemImg = LoadGraph("image\\item.png");//�A�C�e���摜

	Boss_Img = LoadGraph("image\\Boss_1_King.png");//�{�X�摜
	enemy_projectile_Img = LoadGraph("image\\Enemy_Bullet.png");//�G�̉摜

	treasure_Img     = LoadGraph("image\\TreasureItem.png");//����摜
	map_cave_Img     = LoadGraph("image\\Tile_Caves_mod.png");//�}�b�v�`�b�v
}
//�摜�폜
void Resource::Release() {
	DeleteGraph(playerImg);
	DeleteGraph(effectImg);
	DeleteGraph(enemy5Img);
	DeleteGraph(bowImg);
	DeleteGraph(magicImg);
	DeleteGraph(itemImg);
	DeleteGraph(Boss_Img);
	DeleteGraph(weaponImg);
	DeleteGraph(enemy_projectile_Img);
	DeleteGraph(treasure_Img);
	DeleteGraph(map_cave_Img);
}