#include "clear.h"
#include "title.h"
#include "function.h"
#include "Resource.h"

CClear::CClear(CManager* p) :CScene(p) {
	check_img = LoadGraph("image\\check.png");
	cross_img = LoadGraph("image\\cross.png");

	score_update = false;
	//�n�C�X�R�A�̍X�V����
	if (G_SCORE > G_HIGH_SCORE) {
		G_HIGH_SCORE = G_SCORE;
		score_update = true;
	}
}

int CClear::UpDate() {
	if (CheckHitKey(KEY_INPUT_BACK)) {
		manager->Scene_Change(make_unique<CTitle>(manager));
		return 0;
	}
	return 0;
}

void CClear::Draw() {
	//DrawLine(WINDOW_WIDTH / 2 - 33 * 2, 0, WINDOW_WIDTH / 2 - 33 * 2, WINDOW_HEIGHT, 0xff0000);

	SetFontSize(48);
	//�X�R�A�E�n�C�X�R�A�̕\��
	DrawFormatString(WINDOW_WIDTH / 2 - 25 * 6 - 33 * 2, 350, 0xffffff, "SCORE�F%d", G_SCORE);
	DrawFormatString(WINDOW_WIDTH / 2 - 25 * 10 - 33 * 2, 200, 0xffffff, "HIGHSCORE�F%d", G_HIGH_SCORE);
	//�n�C�X�R�A���X�V�������ɏo��
	if (score_update) {
		SetFontSize(16);
		DrawString(WINDOW_WIDTH / 2 - 25 * 10 - 33 * 2, 180, "NEW HIGHSCORE", 0xff0000);
	}
	SetFontSize(64);
	//�^�C�g���ɍs�����@�̕\��
	DrawString(WINDOW_WIDTH / 2 - 33 * 8, 550, "TITLE�FBACKSPACE", 0xffffff);
	SetFontSize(32);
	DrawString(WINDOW_WIDTH / 2 - 10 * 4, 620, "Player1�F", 0xffffff);
	DrawGraph(WINDOW_WIDTH / 2, 700, check_img, true);

	SetFontSize(16);
}