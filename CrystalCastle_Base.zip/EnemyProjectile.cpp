#include "EnemyProjectile.h"
#include "function.h"
#include "player.h"
CEnemyProjectile::CEnemyProjectile(Point _pos,Vector _vec,CMap* _map,int _id,int _no,bool _reverse)
{
	pos = _pos;
	vec = Vector_SetLength(_vec, 6.0f);//��
	HP(1);
	map = _map;
	proj_id = _id;
	is_reverse = _reverse;
	sprite.img = Resource::enemy_projectile_Img;
	sprite.cutX = _no*32;//No���ɒe�̉摜��ς���
	sprite.cutY = _id*32;//ID���ɒe�̎�ނ�ς���
	sprite.width = 32;
	sprite.height = 32;
	sprite.angle = atan2(vec.y, vec.x);
	ID = (int)ObjID::ENEMY_PROJ;
	pri = 5;
	if (_id == 1)
		life = 80.0f;
}

int CEnemyProjectile::Action(const ObjList& base,ObjList& add_base)
{
	switch (proj_id)
	{
	default:
		break;
	//���i
	case 0:
	{
		pos = Add_Point_Vector(pos, vec);
		//�ǂ��ђʂ��Ȃ�
		if (!map->CanMove(pos, 32, 32))
			FLAG = false;
	}break;
	case 1:
	{
		pos = Add_Point_Vector(pos, vec);
		//�ǂ��ђʂ��Ȃ�
		if (!map->CanMove(pos, 32, 32))
			FLAG = false;
	}break;

	}

	//��莞�Ԍo�߂��������
	life--;
	if (life == 0)FLAG = false;

	return 0;
}

void CEnemyProjectile::Draw()
{
	//�`��ʒu���v�Z
	Point draw_pos = CameraToScreen(pos, map->camera);
	//�`��
	sprite.Draw(draw_pos.x, draw_pos.y);
}