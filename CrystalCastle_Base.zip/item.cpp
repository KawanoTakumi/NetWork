#include "item.h"
#include "player.h"

void CItem::GetItem(BaseVector* b) {
	//�擾�������̏���
	CPlayer* p = dynamic_cast<CPlayer*>(b);

	if (this->FLAG == false)return;
	switch (itemNo) {
	case ItemNo::EXP:
	{
		p->GetEXP(value);
		break;
	}
	case ItemNo::HEART:
	{
		p->hp = p->CheckHP(p->hp, value);
		break;
	}
	}
	FLAG = false;
}